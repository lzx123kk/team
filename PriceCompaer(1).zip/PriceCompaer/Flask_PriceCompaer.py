from flask import Flask, render_template, request, redirect, url_for
from tt import main
import tt
import traceback
import pymysql

app = Flask(__name__)


@app.route("/")  # 当访问到127.0.0.1：5000/
def index():
    return render_template("login2.html")


@app.route("/login", methods=['POST', 'GET'])
def login():
    username = request.form.get("username")
    pwd = request.form.get("pwd")
    db = pymysql.connect(host='120.24.20.114', user='root', password='gpnu', db='SEproject', port=3306)
    # 参数分别是数据库的主机地址，用户名，密码，数据库名称，端口号
    # 链接数据库
    cursor = db.cursor()

    try:
        # 执行sql语句
        cursor.execute("select * from user_table where username = %s and password =%s", (username, pwd))
        results = cursor.fetchall()
        print(results)
        print("result: ", len(results))
        if len(results) == 1:
            return redirect("/entry")
        else:
            return render_template('login2.html', msg='用户名或密码不正确')
        # 提交到数据库执行
        db.commit()
    except Exception as e:
        print("error: ", e)
        # 如果发生错误则回滚
        traceback.print_exc()
        db.rollback()
    # 关闭数据库连接
    db.close()


@app.route('/entry', methods=['POST', 'GET'])
def entry():
    return render_template('entry.html',
                           the_title='Welcome to PriceCompare!')


@app.route('/compare', methods=['POST'])
def search_products() -> str:
    word = request.form['word']
    title = '比价结果'
    titles = ('名称', '价格', '地区', '付款人数', '链接', '店名')
    data_one, data_two, results = main(word)
    tt.products_list = []
    return render_template('results.html',
                           the_word=word,
                           the_title=title,
                           the_row_titles=titles,
                           the_data=results,
                           the_pictureone=data_one,
                           the_picturetwo=data_two
                           )


@app.route('/register')
def register():
    return render_template('register.html', msg='注册成功')


@app.route('/register1', methods=['POST', 'GET'])
def register1():
    user = request.form.get("username")
    pwd = request.form.get("password")
    db = pymysql.connect(host='120.24.20.114', user='root', password='gpnu', db='SEproject', port=3306)
    cursor = db.cursor()

    try:
        # 执行sql语句

        cursor.execute("INSERT INTO user_table values(%s, %s)", (user, pwd))
        # 提交到数据库执行
        print("pwd:", pwd)
        db.commit()
        # 注册成功之后跳转到登录页面
        return render_template("login2.html")
    except:
        traceback.print_exc()
        # 如果发生错误则回滚
        db.rollback()
        return '注册失败'
    # 关闭数据库连接
    db.close()


if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5000)
