import re
import requests
import time
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import pymysql

com_count = 0
products_list = []


# 存储数据
def get_into_excel(html, pro_name, cursor):
    #print(html)
    global com_count
    com_name = re.findall(r'"raw_title":"(.*?)"', html)  # 名称
    com_price = re.findall(r'"view_price":"(.*?)"', html)  # 价格~
    com_loc = re.findall(r'"item_loc":"(.*?)"', html)  # 地区
    com_num = re.findall(r'"view_sales":"(.*?)"', html)  # 销量
    link = re.findall(r'"nid":"(.*?)"', html)  # 链接
    store_name = re.findall(r'"nick":"(.*?)"', html)
    com_tab = []  # excel表
    for i in range(len(com_name)):
        try:
            product_name = com_name[i].lower()
            product_name = product_name.replace(' ', '')
            if product_name.find((pro_name.lower()).replace(' ', '')) > 0:
                link[i] = "https://item.taobao.com/item.htm?id=" + link[i]
                com_tab.append((com_name[i], com_price[i], com_loc[i], com_num[i], link[i], store_name[i]))
        except IndexError:
            break
    for temp in range(len(com_tab)):
        products_list.append({
            'raw_title': com_tab[temp][0],
            'view_price': com_tab[temp][1],
            'item_loc': com_tab[temp][2],
            'view_sales': com_tab[temp][3],
            'link': com_tab[temp][4],
            'nick': com_tab[temp][5]
        })
    com_count = com_count + len(com_tab)  # 爬取总量
    if com_count > 0:
        insert_mysql(com_tab, pro_name, cursor)


# pro_name:要查询的商品名称，page:爬取的页数
def get_urls(pro_name, page):
    url = "https://s.taobao.com/search?q=" + pro_name + "&imgfile=&commend=all&ssid=s5-e&search_type=item&sourceId=tb.index&spm" \
                                                        "=a21bo.2017.201856-taobao-item.1&ie=utf8&initiative_id=tbindexz_20170306 "
    urls = [url]
    if page == 1:
        return urls
    for i in range(1, page):
        url = "https://s.taobao.com/search?q=" + pro_name + "&commend=all&ssid=s5-e&search_type=item" \
                                                            "&sourceId=tb.index&spm=a21bo.2017.201856-taobao-item.1&ie=utf8&initiative_id=tbindexz_20170306" \
                                                            "&bcoffset=3&ntoffset=3&p4ppushleft=1%2C48&s=" + str(i * 44)
        urls.append(url)
    return urls


# 获得商品链接
def get_html(url, headers):
    r = requests.get(url, headers=headers)
    r.raise_for_status()
    r.encoding = r.apparent_encoding
    return r


def picture2(product_list):
    price = []
    for i in range(len(product_list)):
        price.append(float(product_list[i].get('view_price')))
    fig = plt.figure(figsize=(8, 4))
    sizes = [0, 0, 0, 0]
    ran_price = price[-1] - price[0]
    len_price = len(price)
    for temp in price:
        if temp <= price[0] + ran_price / 4:
            sizes[0] = sizes[0] + 1
        elif temp <= price[0] + ran_price / 2:
            sizes[1] = sizes[1] + 1
        elif temp <= price[0] + 3 * ran_price / 4:
            sizes[2] = sizes[2] + 1
        else:
            sizes[3] = sizes[3] + 1
    for temp in range(4):
        sizes[temp] = sizes[temp] / len_price
    labels = "{:.2f}~{:.2f}".format(price[0], price[0] + ran_price / 4), "{:.2f}~{:.2f}".format(price[0] + ran_price / 4, price[
        0] + 2 * ran_price / 4), "{:.2f}~{:.2f}".format(price[0] + 2 * ran_price / 4,
                                                price[0] + 3 * ran_price / 4), "{:.2f}~{:.2f}".format(
        price[0] + 3 * ran_price / 4, price[-1])
    explode = (0, 0, 0, 0)
    ax1 = fig.add_subplot(1, 1, 1)
    ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', shadow=False, startangle=90)
    ax1.axis('equal')  # 设置x，y轴刻度一致，这样饼图才能是圆的
    ax1.set_title('pice_distributionpr')
    sio = BytesIO()
    plt.savefig(sio, format='png')
    data = base64.encodebytes(sio.getvalue()).decode()
    return data


def picture1(product_list):  # 展示折线图
    price_two = []
    for i in range(len(product_list)):
        price_two.append(float(product_list[i].get('view_price')))
    len_price = len(price_two)
    product_num = range(len_price)
    fig = plt.figure(figsize=(8, 4))
    ax1 = fig.add_subplot(1, 1, 1)
    ax1.plot(product_num, price_two, color='blue')
    ax1.set_title('price_chart')
    sio = BytesIO()
    plt.savefig(sio, format='png')
    data = base64.encodebytes(sio.getvalue()).decode()
    plt.close()
    return data


def chart(pro_name, page, headers, cursor):
    urls = get_urls(pro_name, page)
    for url in urls:
        html = get_html(url, headers)
        get_into_excel(html.text, pro_name, cursor)
        time.sleep(5)


def create_mysql(pro_name, cursor):
    try:
        sql1 = "CREATE TABLE {}(raw_title varchar(255),view_price decimal(20,4),item_loc varchar(255),view_sales varchar(255),link varchar(255),nick varchar(255))".format(
            pro_name)
        sql2 = "insert into name values(%s);"
        cursor.execute(sql2, pro_name)
        cursor.execute(sql1)
    except Exception as e:
        print("error: ", e)


def find_mysql(pro_name, cursor):
    try:
        sql = "Select * from name where name='{}';".format(pro_name)
        cursor.execute(sql)
        df = cursor.fetchall()
        if len(df) >= 1:
            return 1
        return 0
    except Exception as e:
        print("error: ", e)


def read_mysql(pro_name, cursor):
    try:
        sql = "Select raw_title,view_price,item_loc,view_sales,link,nick from {};".format(pro_name)
        cursor.execute(sql)
        com_tab = cursor.fetchall()
        for temp in range(len(com_tab)):
            products_list.append({
                'raw_title': com_tab[temp][0],
                'view_price': com_tab[temp][1],
                'item_loc': com_tab[temp][2],
                'view_sales': com_tab[temp][3],
                'link': com_tab[temp][4],
                'nick': com_tab[temp][5]
            })
    except Exception as e:
        print("error: ", e)


def insert_mysql(com_tab, pro_name, cursor):
    try:
        sql1 = "insert into {}(raw_title,view_price,item_loc,view_sales,link,nick) values(%s, %s, %s, %s, %s, %s)".format(pro_name)
        cursor.executemany(sql1, com_tab)

    except Exception as e:
        print("error: ", e)


def main(_word):
    pro_name = _word.lower()
    db = pymysql.connect(host='120.24.20.114', user='root', password='gpnu', db='SEproject', port=3306)
    # 参数分别是数据库的主机地址，用户名，密码，数据库名称，端口号
    # 链接数据库
    cursor = db.cursor()
    page = 2
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
        ,
        "cookie": "__wpkreporterwid_=3d55eeb9-19b5-4af9-a8d7-61f5051fb364; miid=205897625319241678; ctoken=MdKHx8qOPlkoT48ccwxriNn8; lego2_cna=MD2RCC4CMCECH4R85HRTU5RK; _m_h5_tk=f50f8205a47060af1b455b19e5a9f0ce_1606058232706; _m_h5_tk_enc=45d24cb9622f4ee4800aedb5e8a68a24; cna=jb4yGMg1SEECAbfuTw/vYkEC; xlly_s=1; _samesite_flag_=true; cookie2=1ac584087c6cd41e59258742d5a19b49; t=675f1b70ff33d6742109a4c79687fdf1; _tb_token_=3eeebb77579a; sgcookie=E100GIZVJAT8unnkCWMl85GzAdh1W2owqbXMKwhEwSdnyj9Jq2gddw1i0i0%2FkTVQDTjUd3vmRFwB79Vn%2BUxHTUKK4Q%3D%3D; unb=3983794605; uc3=nk2=F5RGMcgWh11p8V0%3D&vt3=F8dCufwph9bbxge%2FQGE%3D&id2=UNk%2FSy7i%2FRxwaA%3D%3D&lg2=W5iHLLyFOGW7aA%3D%3D; csg=c83cc6ba; lgc=tb375503612; cookie17=UNk%2FSy7i%2FRxwaA%3D%3D; dnk=tb375503612; skt=eff8a07d506970c1; existShop=MTYwNjA0ODg5Mg%3D%3D; uc4=nk4=0%40FY4NBLDe1XeCXkXfA%2FKggN0MkWOWBw%3D%3D&id4=0%40Ug41Su%2BHJAMvuU%2BxKmWXnw98ymum; tracknick=tb375503612; _cc_=VFC%2FuZ9ajQ%3D%3D; _l_g_=Ug%3D%3D; sg=25b; _nk_=tb375503612; cookie1=BvbS1kiLjLo5Hib06l%2Bg%2BBI%2BRLIBHMVLQGqlC5MJS2M%3D; mt=ci=25_1; uc1=cookie15=WqG3DMC9VAQiUQ%3D%3D&cookie14=Uoe0azas1AgKoA%3D%3D&cookie21=UtASsssme%2BBq&existShop=false&pas=0&cookie16=UIHiLt3xCS3yM2h4eKHS9lpEOw%3D%3D; thw=cn; enc=8aQIW%2BTlIfCd05S8N6Vla%2FZYio4L%2F3xQom9HUQpaJLZ1yum90HAhwwl20w1ahbRB%2F%2BsSRmxgQrtbOBLgvv6B8Q%3D%3D; hng=CN%7Czh-CN%7CCNY%7C156; v=0; tfstk=c9MOBQcsaeYgeHZK4fdhhRwDnrGOafsToGaAH3tLfCPW6FBAhsjKEYIF2CZVWJKd.; l=eBT66gV7OlGHaw4sBO5Zlurza77OFIObzsPzaNbMiInca1PG6UAALNQV73nJJdtjgtCA7F-r09hQ7RhD8MUdgmyD-JluBKWt3xvO.; isg=BDIybAz9uffGnoXLcByucnTcg3gUwzZdN3nA2PwKcOXyj9CJ41J6bXKtfysz_671"
    }  # 把cookie前门的！ax去掉才可用cookie，不过使用频率不可太高
    data = find_mysql(pro_name, cursor)
    print(data)
    if data == 0:
        create_mysql(pro_name, cursor)
        chart(pro_name, page, headers, cursor)
        read_mysql(pro_name, cursor)
    else:
        time.sleep(5)
        read_mysql(pro_name, cursor)
    db.commit()
    db.close()
    lists = []
    product_list = products_list
    product_list = sorted(product_list, key=lambda item: float(item['view_price']), reverse=False)
    lists.append(product_list[0])
    lists.append(product_list[-1])
    num = 0
    for i in range(1, len(product_list) - 1):
        if product_list[i].get('nick').find("旗舰店") > 0:
            lists.append(product_list[i])
            num = num + 1
            if num == 3:
                break
    data_one = picture1(product_list)
    data_two = picture2(product_list)
    return data_one, data_two, lists


if __name__ == "__main__":
    word = input("输入货物:")
    main(word)
